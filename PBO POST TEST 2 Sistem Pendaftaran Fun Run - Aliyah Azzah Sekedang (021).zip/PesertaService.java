/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package service;

import java.util.ArrayList;
import java.util.Scanner;
import model.PaketFunRun;
import model.Peserta;
/**
 *
 * @author aliya
 */
public class PesertaService {
    private ArrayList<Peserta> daftarPeserta = new ArrayList<>();
    private Scanner scanner = new Scanner(System.in);

    public void tambahPeserta(ArrayList<PaketFunRun> paketList) {
        System.out.print("Nama: ");
        String nama = scanner.nextLine();
        System.out.print("Telepon: ");
        String telepon = scanner.nextLine();
        System.out.print("Email: ");
        String email = scanner.nextLine();

        System.out.println("\n=== PILIH PAKET FUN RUN ===");
        for (int i = 0; i < paketList.size(); i++) {
            System.out.println((i + 1) + ". " + paketList.get(i).getNamaPaket() + " (" + paketList.get(i).getFasilitas() + ") - Rp" + paketList.get(i).getHarga());
        }
        System.out.print("Pilih paket (1-" + paketList.size() + "): ");
        int pilihan = scanner.nextInt();
        scanner.nextLine();
        PaketFunRun paketDipilih = paketList.get(pilihan - 1);

        System.out.println("\n=== METODE PEMBAYARAN ===");
        System.out.println("1. Bank Transfer");
        System.out.println("2. E-Wallet");
        System.out.print("Pilih metode: ");
        int metode = scanner.nextInt();
        scanner.nextLine();
        String metodeBayar = (metode == 1) ? "Bank Transfer" : "E-Wallet";

        Peserta pesertaBaru = new Peserta(nama, telepon, email, paketDipilih, metodeBayar);
        daftarPeserta.add(pesertaBaru);
        System.out.println("Peserta berhasil terdaftar. See you!\n");
    }

    public void lihatPeserta() {
        if (daftarPeserta.isEmpty()) {
            System.out.println("Belum ada peserta terdaftar.");
            return;
        }
        System.out.println("\n========== DAFTAR PESERTA ==========");
        for (Peserta p : daftarPeserta) {
            p.infoPeserta();
        }
    }

    public void hapusPeserta() {
        lihatPeserta();
        System.out.print("Masukkan nama peserta yang akan dihapus: ");
        String nama = scanner.nextLine();
        Peserta target = null;
        for (Peserta p : daftarPeserta) {
            if (p.getNama().equalsIgnoreCase(nama)) {
                target = p;
                break;
            }
        }
        if (target != null) {
            daftarPeserta.remove(target);
            System.out.println("Peserta berhasil dihapus.");
        } else {
            System.out.println("Peserta tidak ditemukan.");
        }
    }

    public void editPeserta() {
    if (daftarPeserta.isEmpty()) {
        System.out.println("Belum ada peserta terdaftar.");
        return;
    }

    lihatPeserta();
    System.out.print("Masukkan nama peserta yang akan diedit: ");
    String nama = scanner.nextLine();
    Peserta peserta = null;

    for (Peserta p : daftarPeserta) {
        if (p.getNama().equalsIgnoreCase(nama)) {
            peserta = p;
            break;
        }
    }

    if (peserta == null) {
        System.out.println("Peserta tidak ditemukan.");
        return;
    }

    System.out.println("\n=== EDIT DATA PESERTA ===");

    System.out.print("Nama baru (kosongkan jika tidak diubah): ");
    String namaBaru = scanner.nextLine();
    if (!namaBaru.isEmpty()) peserta.setNama(namaBaru);

    System.out.print("Telepon baru (kosongkan jika tidak diubah): ");
    String teleponBaru = scanner.nextLine();
    if (!teleponBaru.isEmpty()) peserta.setTelepon(teleponBaru);

    System.out.print("Email baru (kosongkan jika tidak diubah): ");
    String emailBaru = scanner.nextLine();
    if (!emailBaru.isEmpty()) peserta.setEmail(emailBaru);

    System.out.println("Data peserta berhasil diperbarui.");
}

    public void cariPeserta() {
        System.out.print("Masukkan nama peserta yang dicari: ");
        String keyword = scanner.nextLine().toLowerCase();
        boolean found = false;
        for (Peserta p : daftarPeserta) {
            if (p.getNama().toLowerCase().contains(keyword)) {
                p.infoPeserta();
                found = true;
            }
        }
        if (!found) System.out.println("Peserta tidak ditemukan.");
    }
}