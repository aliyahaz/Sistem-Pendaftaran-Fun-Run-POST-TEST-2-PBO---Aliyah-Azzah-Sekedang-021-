/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package service;
import java.util.ArrayList;
import model.PaketFunRun;
/**
 *
 * @author aliya
 */
public class PaketService {
    private ArrayList<PaketFunRun> paketList = new ArrayList<>();

    public PaketService() {
        paketList.add(new PaketFunRun("Reguler One Package", 150000, "Kaos + Medali"));
        paketList.add(new PaketFunRun("Reguler Full Package", 250000, "Kaos + Medali + Paket Produk Emina"));
    }

    public ArrayList<PaketFunRun> getPaketList() {
        return paketList;
    }

    public void lihatPaket() {
        System.out.println("\n========== DAFTAR PAKET FUN RUN ==========");
        for (PaketFunRun paket : paketList) {
            paket.infoPaket();
        }
    }
}