/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author aliya
 */
public class Peserta {
    private String nama;
    private String telepon;
    private String email;
    private PaketFunRun paket;
    private String metodeBayar;

    public Peserta(String nama, String telepon, String email, PaketFunRun paket, String metodeBayar) {
        this.nama = nama;
        this.telepon = telepon;
        this.email = email;
        this.paket = paket;
        this.metodeBayar = metodeBayar;
    }

    public String getNama() { return nama; }
    public void setNama(String nama) { this.nama = nama; }

    public String getTelepon() { return telepon; }
    public void setTelepon(String telepon) { this.telepon = telepon; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public PaketFunRun getPaket() { return paket; }
    public void setPaket(PaketFunRun paket) { this.paket = paket; }

    public String getMetodeBayar() { return metodeBayar; }
    public void setMetodeBayar(String metodeBayar) { this.metodeBayar = metodeBayar; }

    public void infoPeserta() {
        System.out.println("======================================");
        System.out.println("Nama Peserta  : " + nama);
        System.out.println("Telepon       : " + telepon);
        System.out.println("Email         : " + email);
        System.out.println("Paket Dipilih : " + paket.getNamaPaket() + " (" + paket.getFasilitas() + ")");
        System.out.println("Metode Bayar  : " + metodeBayar);
        System.out.println("======================================");
    }
}