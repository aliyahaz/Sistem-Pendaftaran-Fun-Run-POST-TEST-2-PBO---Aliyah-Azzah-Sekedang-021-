/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package main;

import java.util.Scanner;
import service.PaketService;
import service.PesertaService;
/**
 *
 * @author aliya
 */
public class Menupendaftaran {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        PaketService paketService = new PaketService();
        PesertaService pesertaService = new PesertaService();
        int pilihan;

        do {
            System.out.println("\nWELCOME TO EMINA FUN RUN!");
            System.out.println("Event seru-seruan lari sehat & fun bareng Emina.");
            System.out.println("Tanggal : 20 Oktober 2025");
            System.out.println("Waktu   : 06.00 WITA - selesai");
            System.out.println("Tempat  : GOR Sempaja, Samarinda");
            System.out.println("\n===== MENU PENDAFTARAN =====");
            System.out.println("1. Tambah Peserta");
            System.out.println("2. Lihat Peserta");
            System.out.println("3. Edit Data Peserta");
            System.out.println("4. Hapus Data Peserta");
            System.out.println("5. Cari Peserta");
            System.out.println("6. Keluar");
            System.out.println("==============================");
            System.out.print("Pilih menu: ");
            pilihan = scanner.nextInt();
            scanner.nextLine();

            switch (pilihan) {
                case 1 -> pesertaService.tambahPeserta(paketService.getPaketList());
                case 2 -> pesertaService.lihatPeserta();
                case 3 -> pesertaService.editPeserta();
                case 4 -> pesertaService.hapusPeserta();
                case 5 -> pesertaService.cariPeserta();
                case 6 -> System.out.println("Thank you and see you on Fun Run!");
                default -> System.out.println("Pilihan tidak valid.");
            }
        } while (pilihan != 6);
    }
}